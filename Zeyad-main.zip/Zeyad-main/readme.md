Handler for discord.js version 13

`npm install` - install all required dependancies

`node index.js` - start the project

Only open pull requests for bug fixes, I want to keep the code as clean as possible, thanks!
